# ArduinoDuckyScript
Various arduino script with rubber ducky like payload

Tested with:
- https://www.ebay.com/itm/New-Mini-ATMEGA32U4-Module-Board-Compatible-For-Arduino-SS-Micro-ATMEGA32U4-/272471577633?hash=item3f70925421

Blog:

https://medium.com/@christoferdirk/penetration-testing-with-arduino-build-your-own-usb-payload-9fd0902ef8fc
