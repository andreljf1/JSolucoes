import courseTab from './profile/course-tab';
import courseStatistics from './profile/statistic';

document.addEventListener( 'DOMContentLoaded', function( event ) {
	courseTab();
	courseStatistics();
} );
