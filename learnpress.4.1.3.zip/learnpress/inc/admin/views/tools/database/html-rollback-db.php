<?php
/**
 * Template tool rollback database.
 *
 * @template html-rollback-db
 * @author  tungnx
 * @package learnpress/admin/views/tools/database
 * @version 1.0.0
 * @since 4.0.2
 */

defined( 'ABSPATH' ) or die();

